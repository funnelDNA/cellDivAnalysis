classdef Block
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        blockS
        blockE
        length
        profile
        body
        stitchS    
    end
    
    methods
    end
    
end

