%%
allFr = allData.allFr;
for kthFr = 1:length(allFr)
    cells = allFr(kthFr).cells.cells;
    for kthCell = 1:length(cells)
        cell = cells(kthCell);
        area2Ana = allFr(kthFr).channel(:,cell.block.blockS:cell.block.blockE);
        area2AnaLarge = zeros(size(area2Ana)+2);
        area2AnaLarge(2:end-1,2:end-1) = area2Ana;
        imagesc(area2AnaLarge); hold on;
        C = contour(area2AnaLarge,[threshold threshold],'linewidth',3,'color','r');  hold off;
        area = polyarea([C(1,2:end) C(1,2)],[C(2,2:end) C(2,2)]);
        %area1 = polyarea([C(1,2:end)],[C(2,2:end)]);
        ;
    end
end