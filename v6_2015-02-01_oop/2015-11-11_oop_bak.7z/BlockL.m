classdef BlockL
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        block
        sLink = []
        kp1sLink = []
        cLink = []
        isSkip = 0
    end
    
    methods
    end
    
end

