classdef Cell
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        block
        mLink = []
        dLink = []
        lLink = []
        isSkip = 0
        cellId = 0
    end
    
    methods
    end
    
end

