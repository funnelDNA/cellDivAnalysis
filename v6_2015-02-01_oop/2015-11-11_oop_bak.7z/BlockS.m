classdef BlockS
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        block
        lLink = []
        km1lLink = []
        isSkip = 0
    end
    
    methods
    end
    
end

